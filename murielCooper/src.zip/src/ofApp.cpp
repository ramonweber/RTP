#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
	font.load("framd.ttf", 300, true, true, true);
}

//--------------------------------------------------------------
void ofApp::update(){

}

//--------------------------------------------------------------
void ofApp::draw(){
	//ofBackground(255);

	vector <ofPath> paths = font.getStringAsPoints("MIT");
	
	//ofSetColor(255, 255, 0, 100);
	ofTranslate(200, 500);
	for (int i = 0; i < paths.size(); i++) {
		// iterate through all letters
		paths[i].setPolyWindingMode(OF_POLY_WINDING_ODD);
		vector <ofPolyline> lines = paths[i].getOutline();

		
		for (int j = 0; j < lines.size(); j++) {
			
			lines[j].setClosed(true);
			lines[j] = lines[j].getResampledBySpacing(4);
			lines[j] = lines[j].getSmoothed(100*0.1);
			
			cout << lines[j];

			ofBeginShape();
			ofSetColor(255, 255, 0, 100);
			for (int k = 0; k < lines[j].size(); k++) {
				ofVertex(lines[j][k]);
			}
			ofEndShape();
			}
		}

		

	
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
